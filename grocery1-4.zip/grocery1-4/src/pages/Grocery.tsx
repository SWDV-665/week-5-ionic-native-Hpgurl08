import React, { useState } from "react";
import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonButton,
  IonModal,
  IonIcon,
  IonInput,
  IonFab,
  IonFabButton,
  IonToast, // Import IonToast
} from "@ionic/react";
import { add } from "ionicons/icons";
import GroceryList from "../components/GroceryList";
import "./Grocery.css";
// Importing action sheets
import { IonActionSheet } from "@ionic/react";


const Grocery: React.FC = () => {
  const [groceryItems, setGroceryItems] = useState<
    { name: string; quantity: string }[]
  >([
    { name: "Apples", quantity: "5" },
    { name: "Bananas", quantity: "3" },
    { name: "Milk", quantity: "1" },
    { name: "Bread", quantity: "2" },
    { name: "Eggs", quantity: "12" },
  ]);
  const [newItem, setNewItem] = useState<{ name: string; quantity: string }>({
    name: "",
    quantity: "",
  });
  const [showPopup, setShowPopup] = useState(false);
  const [showErrorToast, setShowErrorToast] = useState(false); // State for error toast

    const addItemToList = () => {
    if (newItem.name.trim() !== "" && newItem.quantity.trim() !== "") {
      // validate the quantity
      const parsedQuantity = parseInt(newItem.quantity, 10);
      if (!isNaN(parsedQuantity) && parsedQuantity > 0) {
        setGroceryItems([newItem, ...groceryItems]);
        setNewItem({ name: "", quantity: "" });
        // Close the popup after adding the item
        setShowPopup(false);
      } else {
        // Show an error toast
        setShowErrorToast(true);
      }
    }
  };

  //Adding edit functionallity
    const editItem = (index: number) => {
    const newName = prompt('Enter a new name:', groceryItems[index].name);
    const newQuantity = prompt('Enter a new quantity:', groceryItems[index].quantity);

    if (newName !== null && newQuantity !== null) {
      const editedItem = { name: newName, quantity: newQuantity };
      const updatedItems = [...groceryItems];
      updatedItems[index] = editedItem;
      setGroceryItems(updatedItems);
    }
  };
  // Adding share function
  const shareItem = (index: number) => {
    // Implement the share functionality here
    // You can use platform-specific APIs or other methods to share the item
    // For simplicity, let's just log a message for now
    console.log(`Sharing ${groceryItems[index].name}`);
    setSelectedShareIndex(index);
    setShowShareActionSheet(true);
  };

  // Action sheets
  const [showShareActionSheet, setShowShareActionSheet] = useState(false);
  const [selectedShareIndex, setSelectedShareIndex] = useState<number | null>(
    null
  );

  const [shareTarget, setShareTarget] = useState<string | null>(null);

  const handleShareActionSheet = (option: "copyLink" | "share") => {
    const itemToShare = groceryItems[selectedShareIndex!];
    setShowShareActionSheet(false);

    if (option === "copyLink") {
      // Implement copy link functionality (you may need to use Clipboard API)
      console.log(`Link to share: ${itemToShare.name}`);
    } else if (option === "share") {
      // Ask the user for email or phone number
      const shareTarget = prompt("Enter email or phone number:");
      if (shareTarget !== null && shareTarget.trim() !== "") {
        setShareTarget(shareTarget);
        // Implement share functionality (use platform-specific APIs)
        console.log(`Sharing ${itemToShare.name} with ${shareTarget}`);
        // You would typically use an API or library to send the information
      }
    }
  };

  const removeItemFromList = (index: number) => {
    const updatedItems = [...groceryItems];
    updatedItems.splice(index, 1);
    setGroceryItems(updatedItems);
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle className="title">Groceries List</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <GroceryList
          groceryItems={groceryItems}
          removeItemFromList={removeItemFromList}
          editItem={editItem} // Pass the edit function here
          shareItem={shareItem} // Pass the shareItem function
        />
        <IonActionSheet
          isOpen={showShareActionSheet}
          onDidDismiss={() => setShowShareActionSheet(false)}
          buttons={[
            {
              text: "Copy Link",
              handler: () => handleShareActionSheet("copyLink"),
            },
            {
              text: "Share",
              handler: () => handleShareActionSheet("share"),
            },
            {
              text: "Cancel",
              role: "cancel",
            },
          ]}
        >
          {shareTarget !== null && (
            <IonInput
              type="text"
              value={shareTarget}
              readonly
              placeholder="Email or Phone"
            />
          )}
          {shareTarget !== null && (
            <IonButton expand="block" onClick={() => setShareTarget(null)}>
              Change Target
            </IonButton>
          )}
        </IonActionSheet>
        <IonModal isOpen={showPopup}>
          <IonContent className="center-content">
            <IonToolbar>
              <IonButton slot="end" onClick={() => setShowPopup(false)}>
                X
              </IonButton>
            </IonToolbar>
            <div className="form-container">
              <IonInput
              className="input"
                type="text"
                placeholder="Enter the item name"
                value={newItem.name}
                onIonChange={(e) =>
                  setNewItem({ ...newItem, name: e.detail.value! })
                }
              />
              <IonInput
               className="input"
                type="text"
                placeholder="Enter the quantity"
                value={newItem.quantity}
                onIonChange={(e) =>
                  setNewItem({ ...newItem, quantity: e.detail.value! })
                }
              />
              <IonButton expand="block" onClick={addItemToList}>
                Add
              </IonButton>
            </div>
          </IonContent>
        </IonModal>

        <IonFab vertical="bottom" horizontal="end" slot="fixed">
          <IonFabButton onClick={() => setShowPopup(true)}>
            <IonIcon icon={add}>
              <IonIcon icon={add} />
            </IonIcon>
            
          </IonFabButton>
        </IonFab>

        <IonToast
          isOpen={showErrorToast}
          onDidDismiss={() => setShowErrorToast(false)}
          message="Invalid quantity. please enter a valid positive number. e.g 1,2,3..."
          duration={2000} // Duration (2 seconds)
          color="danger" 
        />
      </IonContent>
    </IonPage>
  );
};

export default Grocery;
